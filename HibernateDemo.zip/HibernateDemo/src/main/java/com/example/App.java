package com.example;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.example.model.Student;
import com.example.util.HibernateUtil;

public class App {

	public static void main(String[] args) {
		Student student = new Student(1, "John");

        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();

        session.persist(student); // ← This should work if all setup is correct

        tx.commit();
        session.close();

	}

}
